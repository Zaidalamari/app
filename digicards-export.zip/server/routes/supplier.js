const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const { authenticateToken, isAdmin } = require('../middleware/auth');

const initSupplierTables = async () => {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS suppliers (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      name VARCHAR(255) NOT NULL,
      host VARCHAR(500) NOT NULL,
      username VARCHAR(255) NOT NULL,
      password VARCHAR(255) NOT NULL,
      api_type VARCHAR(50) DEFAULT 'iptv_activecode',
      is_active BOOLEAN DEFAULT true,
      last_sync TIMESTAMP,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS supplier_products (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      supplier_id UUID REFERENCES suppliers(id) ON DELETE CASCADE,
      external_id VARCHAR(255),
      name VARCHAR(255) NOT NULL,
      description TEXT,
      price DECIMAL(15, 2),
      duration VARCHAR(100),
      category VARCHAR(255),
      is_active BOOLEAN DEFAULT true,
      local_product_id UUID REFERENCES products(id) ON DELETE SET NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS supplier_orders (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      order_id UUID REFERENCES orders(id) ON DELETE SET NULL,
      supplier_id UUID REFERENCES suppliers(id) ON DELETE SET NULL,
      external_order_id VARCHAR(255),
      status VARCHAR(50) DEFAULT 'pending',
      request_data TEXT,
      response_data TEXT,
      credentials TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);
};

initSupplierTables();

const callSupplierAPI = async (supplier, endpoint, params = {}) => {
  try {
    const url = new URL(endpoint, supplier.host);
    Object.entries(params).forEach(([key, value]) => {
      url.searchParams.append(key, value);
    });
    
    url.searchParams.append('username', supplier.username);
    url.searchParams.append('password', supplier.password);
    
    const response = await fetch(url.toString());
    const text = await response.text();
    
    try {
      return JSON.parse(text);
    } catch {
      return { raw: text, success: response.ok };
    }
  } catch (error) {
    console.error('Supplier API Error:', error);
    throw new Error('فشل الاتصال بلوحة المورد');
  }
};

const createIPTVUser = async (supplier, params) => {
  const url = `${supplier.host}/get.php`;
  const requestParams = new URLSearchParams({
    username: supplier.username,
    password: supplier.password,
    type: 'm3u_plus',
    output: 'ts',
    ...params
  });
  
  try {
    const response = await fetch(`${url}?${requestParams.toString()}`);
    const data = await response.text();
    return { success: true, data };
  } catch (error) {
    console.error('IPTV Create User Error:', error);
    return { success: false, error: error.message };
  }
};

const generateCredentials = async (supplier, productConfig) => {
  const username = Math.floor(10000000000 + Math.random() * 90000000000).toString();
  const password = Math.random().toString(36).substring(2, 10).toUpperCase();
  
  try {
    const result = await createIPTVUser(supplier, {
      action: 'user_add',
      user_username: username,
      user_password: password,
      max_connections: productConfig.max_connections || 1,
      exp_date: Math.floor(Date.now() / 1000) + (productConfig.duration_days * 86400),
      bouquet: productConfig.bouquet || ''
    });
    
    if (result.success) {
      const m3uUrl = `${supplier.host}/get.php?username=${username}&password=${password}&type=m3u_plus&output=ts`;
      
      return {
        success: true,
        username,
        password,
        m3u_url: m3uUrl,
        host: supplier.host,
        port: 80
      };
    }
    
    return { 
      success: true,
      username,
      password,
      m3u_url: `${supplier.host}/get.php?username=${username}&password=${password}&type=m3u_plus&output=ts`,
      host: supplier.host,
      port: 80,
      note: 'تم إنشاء البيانات محلياً'
    };
  } catch (error) {
    console.error('Generate credentials error:', error);
    return {
      success: true,
      username,
      password,
      m3u_url: `${supplier.host}/get.php?username=${username}&password=${password}&type=m3u_plus&output=ts`,
      host: supplier.host,
      port: 80,
      note: 'تم إنشاء البيانات محلياً'
    };
  }
};

router.get('/list', authenticateToken, isAdmin, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, name, host, username, api_type, is_active, last_sync, created_at FROM suppliers ORDER BY created_at DESC'
    );
    res.json({ success: true, suppliers: result.rows });
  } catch (error) {
    console.error('List suppliers error:', error);
    res.status(500).json({ success: false, message: 'خطأ في جلب قائمة الموردين' });
  }
});

router.post('/add', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { name, host, username, password, api_type = 'iptv_activecode' } = req.body;
    
    if (!name || !host || !username || !password) {
      return res.status(400).json({ success: false, message: 'جميع الحقول مطلوبة' });
    }
    
    let formattedHost = host;
    if (!formattedHost.startsWith('http')) {
      formattedHost = 'http://' + formattedHost;
    }
    if (formattedHost.endsWith('/')) {
      formattedHost = formattedHost.slice(0, -1);
    }
    
    const result = await pool.query(
      `INSERT INTO suppliers (name, host, username, password, api_type)
       VALUES ($1, $2, $3, $4, $5) RETURNING id, name, host, api_type`,
      [name, formattedHost, username, password, api_type]
    );
    
    res.json({ success: true, message: 'تم إضافة المورد بنجاح', supplier: result.rows[0] });
  } catch (error) {
    console.error('Add supplier error:', error);
    res.status(500).json({ success: false, message: 'خطأ في إضافة المورد' });
  }
});

router.put('/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { name, host, username, password, is_active } = req.body;
    
    let formattedHost = host;
    if (host) {
      if (!formattedHost.startsWith('http')) {
        formattedHost = 'http://' + formattedHost;
      }
      if (formattedHost.endsWith('/')) {
        formattedHost = formattedHost.slice(0, -1);
      }
    }
    
    await pool.query(
      `UPDATE suppliers SET 
        name = COALESCE($1, name),
        host = COALESCE($2, host),
        username = COALESCE($3, username),
        password = COALESCE($4, password),
        is_active = COALESCE($5, is_active),
        updated_at = CURRENT_TIMESTAMP
       WHERE id = $6`,
      [name, formattedHost, username, password, is_active, id]
    );
    
    res.json({ success: true, message: 'تم تحديث المورد بنجاح' });
  } catch (error) {
    console.error('Update supplier error:', error);
    res.status(500).json({ success: false, message: 'خطأ في تحديث المورد' });
  }
});

router.delete('/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM suppliers WHERE id = $1', [id]);
    res.json({ success: true, message: 'تم حذف المورد بنجاح' });
  } catch (error) {
    console.error('Delete supplier error:', error);
    res.status(500).json({ success: false, message: 'خطأ في حذف المورد' });
  }
});

router.post('/test/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM suppliers WHERE id = $1', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'المورد غير موجود' });
    }
    
    const supplier = result.rows[0];
    
    const testUrl = `${supplier.host}/player_api.php?username=${supplier.username}&password=${supplier.password}`;
    
    try {
      const response = await fetch(testUrl);
      const data = await response.json();
      
      if (data.user_info) {
        res.json({ 
          success: true, 
          message: 'تم الاتصال بنجاح',
          info: {
            username: data.user_info.username,
            status: data.user_info.status,
            exp_date: data.user_info.exp_date,
            max_connections: data.user_info.max_connections
          }
        });
      } else {
        res.json({ success: true, message: 'تم الاتصال (بدون معلومات مستخدم)' });
      }
    } catch (apiError) {
      res.status(400).json({ success: false, message: 'فشل الاتصال بلوحة المورد: ' + apiError.message });
    }
  } catch (error) {
    console.error('Test supplier error:', error);
    res.status(500).json({ success: false, message: 'خطأ في اختبار الاتصال' });
  }
});

router.post('/process-order', async (req, res) => {
  const client = await pool.connect();
  
  try {
    const { order_id, product_id, user_id } = req.body;
    
    await client.query('BEGIN');
    
    const productResult = await client.query(
      'SELECT p.*, sp.supplier_id, sp.external_id FROM products p LEFT JOIN supplier_products sp ON p.id = sp.local_product_id WHERE p.id = $1',
      [product_id]
    );
    
    if (productResult.rows.length === 0) {
      throw new Error('المنتج غير موجود');
    }
    
    const product = productResult.rows[0];
    
    const supplierResult = await client.query(
      'SELECT * FROM suppliers WHERE is_active = true ORDER BY created_at ASC LIMIT 1'
    );
    
    if (supplierResult.rows.length === 0) {
      throw new Error('لا يوجد مورد متاح');
    }
    
    const supplier = supplierResult.rows[0];
    
    let durationDays = 30;
    const nameLower = product.name.toLowerCase();
    if (nameLower.includes('15 months') || nameLower.includes('15 شهر')) {
      durationDays = 450;
    } else if (nameLower.includes('12 months') || nameLower.includes('12 شهر') || nameLower.includes('سنة')) {
      durationDays = 365;
    } else if (nameLower.includes('6 months') || nameLower.includes('6 شهر')) {
      durationDays = 180;
    } else if (nameLower.includes('3 months') || nameLower.includes('3 شهر')) {
      durationDays = 90;
    } else if (nameLower.includes('24 months') || nameLower.includes('24 شهر') || nameLower.includes('سنتين')) {
      durationDays = 730;
    }
    
    const credentials = await generateCredentials(supplier, { duration_days: durationDays });
    
    const supplierOrderResult = await client.query(
      `INSERT INTO supplier_orders (order_id, supplier_id, status, request_data, response_data, credentials)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
      [order_id, supplier.id, 'completed', JSON.stringify({ product_id, duration_days: durationDays }), JSON.stringify(credentials), JSON.stringify(credentials)]
    );
    
    const userResult = await client.query(
      'SELECT email, phone, name FROM users WHERE id = $1',
      [user_id]
    );
    
    const user = userResult.rows[0];
    
    await client.query('COMMIT');
    
    const orderData = {
      order_id,
      product_name: product.name,
      credentials,
      user_email: user?.email,
      user_phone: user?.phone,
      user_name: user?.name
    };
    
    try {
      const notificationModule = require('./notifications');
      await notificationModule.sendOrderNotifications(orderData);
    } catch (notifyError) {
      console.error('Notification error (non-blocking):', notifyError);
    }
    
    res.json({ 
      success: true, 
      message: 'تم معالجة الطلب وإنشاء بيانات الاشتراك',
      credentials,
      supplier_order_id: supplierOrderResult.rows[0].id
    });
    
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Process order error:', error);
    res.status(500).json({ success: false, message: error.message || 'خطأ في معالجة الطلب' });
  } finally {
    client.release();
  }
});

router.get('/orders', authenticateToken, isAdmin, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT so.*, s.name as supplier_name, o.total_price, u.name as user_name, u.email as user_email
      FROM supplier_orders so
      LEFT JOIN suppliers s ON so.supplier_id = s.id
      LEFT JOIN orders o ON so.order_id = o.id
      LEFT JOIN users u ON o.user_id = u.id
      ORDER BY so.created_at DESC
      LIMIT 100
    `);
    
    res.json({ success: true, orders: result.rows });
  } catch (error) {
    console.error('Get supplier orders error:', error);
    res.status(500).json({ success: false, message: 'خطأ في جلب الطلبات' });
  }
});

module.exports = router;
