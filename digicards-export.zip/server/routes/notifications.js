const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const { authenticateToken, isAdmin } = require('../middleware/auth');

const initNotificationTables = async () => {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS notification_settings (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      provider VARCHAR(50) NOT NULL,
      config TEXT NOT NULL,
      is_active BOOLEAN DEFAULT false,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);
  
  await pool.query(`
    CREATE TABLE IF NOT EXISTS notification_logs (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      order_id UUID,
      type VARCHAR(50) NOT NULL,
      recipient VARCHAR(255),
      status VARCHAR(50) DEFAULT 'pending',
      message TEXT,
      response TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);
};

initNotificationTables();

const sendWhatsAppMessage = async (phone, message, settings) => {
  if (!settings || !settings.is_active) {
    console.log('WhatsApp not configured, logging message:', { phone, message });
    return { success: true, simulated: true };
  }
  
  const config = JSON.parse(settings.config);
  
  try {
    if (config.provider === 'ultramsg') {
      const response = await fetch(`https://api.ultramsg.com/${config.instance_id}/messages/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: config.token,
          to: phone,
          body: message
        })
      });
      return await response.json();
    } else if (config.provider === 'twilio') {
      const accountSid = config.account_sid;
      const authToken = config.auth_token;
      const from = config.from_number;
      
      const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`, {
        method: 'POST',
        headers: {
          'Authorization': 'Basic ' + Buffer.from(`${accountSid}:${authToken}`).toString('base64'),
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          To: `whatsapp:${phone}`,
          From: `whatsapp:${from}`,
          Body: message
        })
      });
      return await response.json();
    }
    
    return { success: true, simulated: true };
  } catch (error) {
    console.error('WhatsApp send error:', error);
    return { success: false, error: error.message };
  }
};

const sendSMS = async (phone, message, settings) => {
  if (!settings || !settings.is_active) {
    console.log('SMS not configured, logging message:', { phone, message });
    return { success: true, simulated: true };
  }
  
  const config = JSON.parse(settings.config);
  
  try {
    if (config.provider === 'twilio') {
      const accountSid = config.account_sid;
      const authToken = config.auth_token;
      const from = config.from_number;
      
      const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`, {
        method: 'POST',
        headers: {
          'Authorization': 'Basic ' + Buffer.from(`${accountSid}:${authToken}`).toString('base64'),
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          To: phone,
          From: from,
          Body: message
        })
      });
      return await response.json();
    } else if (config.provider === 'unifonic') {
      const response = await fetch('https://rest.unifonic.com/rest/SMS/Messages/Send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          AppSid: config.app_sid,
          SenderID: config.sender_id,
          Recipient: phone,
          Body: message
        })
      });
      return await response.json();
    } else if (config.provider === 'msegat') {
      const response = await fetch('https://www.msegat.com/gw/sendsms.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiKey: config.api_key,
          userName: config.username,
          userSender: config.sender_name,
          numbers: phone,
          msg: message
        })
      });
      return await response.json();
    }
    
    return { success: true, simulated: true };
  } catch (error) {
    console.error('SMS send error:', error);
    return { success: false, error: error.message };
  }
};

const sendEmail = async (email, subject, htmlContent, settings) => {
  if (!settings || !settings.is_active) {
    console.log('Email not configured, logging:', { email, subject });
    return { success: true, simulated: true };
  }
  
  const config = JSON.parse(settings.config);
  
  try {
    if (config.provider === 'sendgrid') {
      const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${config.api_key}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          personalizations: [{ to: [{ email }] }],
          from: { email: config.from_email, name: config.from_name || 'DigiCards' },
          subject,
          content: [{ type: 'text/html', value: htmlContent }]
        })
      });
      return { success: response.ok };
    } else if (config.provider === 'mailgun') {
      const formData = new URLSearchParams();
      formData.append('from', `${config.from_name || 'DigiCards'} <${config.from_email}>`);
      formData.append('to', email);
      formData.append('subject', subject);
      formData.append('html', htmlContent);
      
      const response = await fetch(`https://api.mailgun.net/v3/${config.domain}/messages`, {
        method: 'POST',
        headers: {
          'Authorization': 'Basic ' + Buffer.from(`api:${config.api_key}`).toString('base64')
        },
        body: formData
      });
      return await response.json();
    }
    
    return { success: true, simulated: true };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
};

const formatOrderMessage = (orderData, type = 'text') => {
  const { product_name, credentials, order_id } = orderData;
  
  const textMessage = `
🎉 تم تأكيد طلبك بنجاح!

📦 المنتج: ${product_name}
🔑 رقم الطلب: ${order_id}

━━━━━━━━━━━━━━━
📡 بيانات الاشتراك:
━━━━━━━━━━━━━━━
👤 اسم المستخدم: ${credentials.username}
🔐 كلمة المرور: ${credentials.password}
🌐 الرابط: ${credentials.host}

━━━━━━━━━━━━━━━
🔗 رابط M3U:
${credentials.m3u_url}
━━━━━━━━━━━━━━━

شكراً لتعاملك معنا! 💚
  `.trim();
  
  const htmlMessage = `
    <div dir="rtl" style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #f9f9f9;">
      <div style="background: #10b981; color: white; padding: 20px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="margin: 0;">🎉 تم تأكيد طلبك!</h1>
      </div>
      <div style="background: white; padding: 30px; border-radius: 0 0 10px 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
        <h2 style="color: #333; border-bottom: 2px solid #10b981; padding-bottom: 10px;">تفاصيل الطلب</h2>
        <p><strong>المنتج:</strong> ${product_name}</p>
        <p><strong>رقم الطلب:</strong> ${order_id}</p>
        
        <h2 style="color: #333; border-bottom: 2px solid #10b981; padding-bottom: 10px; margin-top: 30px;">بيانات الاشتراك</h2>
        <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 15px 0;">
          <p><strong>👤 اسم المستخدم:</strong> <code style="background: #e8e8e8; padding: 3px 8px; border-radius: 4px;">${credentials.username}</code></p>
          <p><strong>🔐 كلمة المرور:</strong> <code style="background: #e8e8e8; padding: 3px 8px; border-radius: 4px;">${credentials.password}</code></p>
          <p><strong>🌐 السيرفر:</strong> ${credentials.host}</p>
        </div>
        
        <h3 style="color: #333;">رابط M3U:</h3>
        <div style="background: #1f2937; color: #10b981; padding: 15px; border-radius: 8px; word-break: break-all; font-size: 12px;">
          ${credentials.m3u_url}
        </div>
        
        <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee;">
          <p style="color: #666;">شكراً لتعاملك معنا! 💚</p>
        </div>
      </div>
    </div>
  `;
  
  return type === 'html' ? htmlMessage : textMessage;
};

const sendOrderNotifications = async (orderData) => {
  const { user_email, user_phone, order_id } = orderData;
  const results = { whatsapp: null, sms: null, email: null };
  
  try {
    const settingsResult = await pool.query('SELECT * FROM notification_settings WHERE is_active = true');
    const settingsMap = {};
    settingsResult.rows.forEach(s => { settingsMap[s.provider] = s; });
    
    const textMessage = formatOrderMessage(orderData, 'text');
    const htmlMessage = formatOrderMessage(orderData, 'html');
    
    if (user_phone) {
      const cleanPhone = user_phone.replace(/\D/g, '');
      
      results.whatsapp = await sendWhatsAppMessage(cleanPhone, textMessage, settingsMap.whatsapp);
      await pool.query(
        `INSERT INTO notification_logs (order_id, type, recipient, status, message, response)
         VALUES ($1, 'whatsapp', $2, $3, $4, $5)`,
        [order_id, user_phone, results.whatsapp?.success ? 'sent' : 'failed', textMessage, JSON.stringify(results.whatsapp)]
      );
      
      results.sms = await sendSMS(cleanPhone, textMessage.substring(0, 160) + '...', settingsMap.sms);
      await pool.query(
        `INSERT INTO notification_logs (order_id, type, recipient, status, message, response)
         VALUES ($1, 'sms', $2, $3, $4, $5)`,
        [order_id, user_phone, results.sms?.success ? 'sent' : 'failed', textMessage.substring(0, 160), JSON.stringify(results.sms)]
      );
    }
    
    if (user_email) {
      results.email = await sendEmail(user_email, `تأكيد الطلب #${order_id}`, htmlMessage, settingsMap.email);
      await pool.query(
        `INSERT INTO notification_logs (order_id, type, recipient, status, message, response)
         VALUES ($1, 'email', $2, $3, $4, $5)`,
        [order_id, user_email, results.email?.success ? 'sent' : 'failed', htmlMessage, JSON.stringify(results.email)]
      );
    }
    
    return results;
  } catch (error) {
    console.error('Send notifications error:', error);
    return results;
  }
};

router.get('/settings', authenticateToken, isAdmin, async (req, res) => {
  try {
    const result = await pool.query('SELECT id, provider, is_active, created_at FROM notification_settings ORDER BY provider');
    res.json({ success: true, settings: result.rows });
  } catch (error) {
    console.error('Get notification settings error:', error);
    res.status(500).json({ success: false, message: 'خطأ في جلب الإعدادات' });
  }
});

router.post('/settings', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { provider, config, is_active } = req.body;
    
    if (!provider || !config) {
      return res.status(400).json({ success: false, message: 'البيانات غير مكتملة' });
    }
    
    const existing = await pool.query('SELECT id FROM notification_settings WHERE provider = $1', [provider]);
    
    if (existing.rows.length > 0) {
      await pool.query(
        'UPDATE notification_settings SET config = $1, is_active = $2, updated_at = CURRENT_TIMESTAMP WHERE provider = $3',
        [JSON.stringify(config), is_active ?? true, provider]
      );
    } else {
      await pool.query(
        'INSERT INTO notification_settings (provider, config, is_active) VALUES ($1, $2, $3)',
        [provider, JSON.stringify(config), is_active ?? true]
      );
    }
    
    res.json({ success: true, message: 'تم حفظ الإعدادات بنجاح' });
  } catch (error) {
    console.error('Save notification settings error:', error);
    res.status(500).json({ success: false, message: 'خطأ في حفظ الإعدادات' });
  }
});

router.get('/logs', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { limit = 50, offset = 0 } = req.query;
    const result = await pool.query(
      'SELECT * FROM notification_logs ORDER BY created_at DESC LIMIT $1 OFFSET $2',
      [limit, offset]
    );
    res.json({ success: true, logs: result.rows });
  } catch (error) {
    console.error('Get notification logs error:', error);
    res.status(500).json({ success: false, message: 'خطأ في جلب السجلات' });
  }
});

router.post('/test', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { type, recipient } = req.body;
    
    const testData = {
      order_id: 'TEST-' + Date.now(),
      product_name: 'اشتراك تجريبي - 12 شهر',
      credentials: {
        username: '12345678901',
        password: 'TESTPASS',
        host: 'http://example.com',
        m3u_url: 'http://example.com/get.php?username=12345678901&password=TESTPASS&type=m3u_plus'
      },
      user_email: type === 'email' ? recipient : null,
      user_phone: type !== 'email' ? recipient : null
    };
    
    const settingsResult = await pool.query('SELECT * FROM notification_settings WHERE provider = $1', [type]);
    const settings = settingsResult.rows[0];
    
    let result;
    const message = formatOrderMessage(testData, type === 'email' ? 'html' : 'text');
    
    if (type === 'whatsapp') {
      result = await sendWhatsAppMessage(recipient, message, settings);
    } else if (type === 'sms') {
      result = await sendSMS(recipient, message.substring(0, 160), settings);
    } else if (type === 'email') {
      result = await sendEmail(recipient, 'رسالة اختبار من DigiCards', message, settings);
    }
    
    res.json({ success: true, result, simulated: !settings?.is_active });
  } catch (error) {
    console.error('Test notification error:', error);
    res.status(500).json({ success: false, message: 'خطأ في إرسال الاختبار' });
  }
});

module.exports = router;
module.exports.sendOrderNotifications = sendOrderNotifications;
module.exports.formatOrderMessage = formatOrderMessage;
