import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

export default function AdminNotifications() {
  const [settings, setSettings] = useState([]);
  const [logs, setLogs] = useState([]);
  const [activeTab, setActiveTab] = useState('settings');
  const [loading, setLoading] = useState(true);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState(null);
  const [configForm, setConfigForm] = useState({});
  const [testRecipient, setTestRecipient] = useState('');

  const token = localStorage.getItem('token');

  const providers = {
    whatsapp: {
      name: 'واتساب',
      icon: '💬',
      fields: [
        { key: 'provider', type: 'select', label: 'المزود', options: [
          { value: 'ultramsg', label: 'UltraMsg' },
          { value: 'twilio', label: 'Twilio' }
        ]},
        { key: 'instance_id', type: 'text', label: 'Instance ID', showIf: (c) => c.provider === 'ultramsg' },
        { key: 'token', type: 'text', label: 'Token', showIf: (c) => c.provider === 'ultramsg' },
        { key: 'account_sid', type: 'text', label: 'Account SID', showIf: (c) => c.provider === 'twilio' },
        { key: 'auth_token', type: 'password', label: 'Auth Token', showIf: (c) => c.provider === 'twilio' },
        { key: 'from_number', type: 'text', label: 'رقم المرسل', showIf: (c) => c.provider === 'twilio' }
      ]
    },
    sms: {
      name: 'رسائل SMS',
      icon: '📱',
      fields: [
        { key: 'provider', type: 'select', label: 'المزود', options: [
          { value: 'twilio', label: 'Twilio' },
          { value: 'unifonic', label: 'Unifonic' },
          { value: 'msegat', label: 'Msegat' }
        ]},
        { key: 'account_sid', type: 'text', label: 'Account SID', showIf: (c) => c.provider === 'twilio' },
        { key: 'auth_token', type: 'password', label: 'Auth Token', showIf: (c) => c.provider === 'twilio' },
        { key: 'from_number', type: 'text', label: 'رقم المرسل', showIf: (c) => c.provider === 'twilio' },
        { key: 'app_sid', type: 'text', label: 'App SID', showIf: (c) => c.provider === 'unifonic' },
        { key: 'sender_id', type: 'text', label: 'Sender ID', showIf: (c) => c.provider === 'unifonic' },
        { key: 'api_key', type: 'text', label: 'API Key', showIf: (c) => c.provider === 'msegat' },
        { key: 'username', type: 'text', label: 'اسم المستخدم', showIf: (c) => c.provider === 'msegat' },
        { key: 'sender_name', type: 'text', label: 'اسم المرسل', showIf: (c) => c.provider === 'msegat' }
      ]
    },
    email: {
      name: 'البريد الإلكتروني',
      icon: '📧',
      fields: [
        { key: 'provider', type: 'select', label: 'المزود', options: [
          { value: 'sendgrid', label: 'SendGrid' },
          { value: 'mailgun', label: 'Mailgun' }
        ]},
        { key: 'api_key', type: 'password', label: 'API Key' },
        { key: 'from_email', type: 'email', label: 'بريد المرسل' },
        { key: 'from_name', type: 'text', label: 'اسم المرسل' },
        { key: 'domain', type: 'text', label: 'النطاق', showIf: (c) => c.provider === 'mailgun' }
      ]
    }
  };

  const fetchSettings = async () => {
    try {
      const res = await fetch('/api/notifications/settings', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setSettings(data.settings || []);
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchLogs = async () => {
    try {
      const res = await fetch('/api/notifications/logs', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setLogs(data.logs || []);
      }
    } catch (error) {
      console.error('Error fetching logs:', error);
    }
  };

  useEffect(() => {
    fetchSettings();
    fetchLogs();
  }, []);

  const openConfig = (providerKey) => {
    const existing = settings.find(s => s.provider === providerKey);
    setSelectedProvider(providerKey);
    setConfigForm(existing ? { ...JSON.parse(existing.config || '{}'), is_active: existing.is_active } : { provider: providers[providerKey].fields[0]?.options?.[0]?.value });
    setShowConfigModal(true);
  };

  const saveConfig = async () => {
    try {
      const { is_active, ...config } = configForm;
      const res = await fetch('/api/notifications/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          provider: selectedProvider,
          config,
          is_active: is_active ?? true
        })
      });
      
      const data = await res.json();
      if (data.success) {
        setShowConfigModal(false);
        fetchSettings();
      } else {
        alert(data.message);
      }
    } catch (error) {
      console.error('Error saving config:', error);
    }
  };

  const testNotification = async (type) => {
    if (!testRecipient) {
      alert('أدخل رقم أو بريد للاختبار');
      return;
    }
    
    try {
      const res = await fetch('/api/notifications/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ type, recipient: testRecipient })
      });
      
      const data = await res.json();
      if (data.success) {
        alert(data.simulated ? 'تم إرسال الاختبار (محاكاة - الخدمة غير مفعلة)' : 'تم إرسال الاختبار بنجاح');
      } else {
        alert('فشل الإرسال: ' + data.message);
      }
    } catch (error) {
      console.error('Test error:', error);
    }
  };

  const isProviderActive = (key) => settings.find(s => s.provider === key)?.is_active;

  return (
    <div className="min-h-screen bg-gray-900 text-white" dir="rtl">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold">إعدادات الإشعارات</h1>
            <p className="text-gray-400 mt-2">إرسال بيانات الطلب للعملاء عبر واتساب وSMS والبريد</p>
          </div>
          <Link to="/admin" className="bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded-lg">
            العودة للوحة
          </Link>
        </div>

        <div className="flex gap-4 mb-6">
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-4 py-2 rounded-lg ${activeTab === 'settings' ? 'bg-green-600' : 'bg-gray-700'}`}
          >
            الإعدادات
          </button>
          <button
            onClick={() => setActiveTab('logs')}
            className={`px-4 py-2 rounded-lg ${activeTab === 'logs' ? 'bg-green-600' : 'bg-gray-700'}`}
          >
            السجلات
          </button>
          <button
            onClick={() => setActiveTab('test')}
            className={`px-4 py-2 rounded-lg ${activeTab === 'test' ? 'bg-green-600' : 'bg-gray-700'}`}
          >
            اختبار
          </button>
        </div>

        {activeTab === 'settings' && (
          <div className="grid md:grid-cols-3 gap-6">
            {Object.entries(providers).map(([key, provider]) => (
              <div key={key} className="bg-gray-800 rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-3xl">{provider.icon}</span>
                  <div>
                    <h3 className="text-xl font-semibold">{provider.name}</h3>
                    <span className={`text-xs px-2 py-1 rounded ${isProviderActive(key) ? 'bg-green-600' : 'bg-gray-600'}`}>
                      {isProviderActive(key) ? 'مفعل' : 'غير مفعل'}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => openConfig(key)}
                  className="w-full bg-blue-600 hover:bg-blue-500 py-2 rounded-lg"
                >
                  إعداد
                </button>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'logs' && (
          <div className="bg-gray-800 rounded-xl p-6">
            <h2 className="text-xl font-semibold mb-4">سجل الإشعارات</h2>
            {logs.length === 0 ? (
              <p className="text-center text-gray-400 py-8">لا توجد سجلات</p>
            ) : (
              <div className="space-y-3 max-h-[60vh] overflow-auto">
                {logs.map(log => (
                  <div key={log.id} className="bg-gray-700 rounded-lg p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className={`text-xs px-2 py-1 rounded ${
                          log.type === 'whatsapp' ? 'bg-green-600' :
                          log.type === 'sms' ? 'bg-blue-600' : 'bg-purple-600'
                        }`}>
                          {log.type === 'whatsapp' ? 'واتساب' :
                           log.type === 'sms' ? 'SMS' : 'بريد'}
                        </span>
                        <p className="mt-2">{log.recipient}</p>
                      </div>
                      <span className={`px-2 py-1 rounded text-xs ${
                        log.status === 'sent' ? 'bg-green-600' : 'bg-red-600'
                      }`}>
                        {log.status === 'sent' ? 'تم الإرسال' : 'فشل'}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      {new Date(log.created_at).toLocaleString('ar')}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'test' && (
          <div className="bg-gray-800 rounded-xl p-6 max-w-md">
            <h2 className="text-xl font-semibold mb-4">اختبار الإشعارات</h2>
            <div className="mb-4">
              <label className="block text-sm text-gray-400 mb-1">رقم الهاتف أو البريد</label>
              <input
                type="text"
                value={testRecipient}
                onChange={(e) => setTestRecipient(e.target.value)}
                className="w-full bg-gray-700 rounded-lg px-4 py-2"
                placeholder="+966500000000 أو email@example.com"
              />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <button
                onClick={() => testNotification('whatsapp')}
                className="bg-green-600 hover:bg-green-500 py-2 rounded-lg"
              >
                واتساب
              </button>
              <button
                onClick={() => testNotification('sms')}
                className="bg-blue-600 hover:bg-blue-500 py-2 rounded-lg"
              >
                SMS
              </button>
              <button
                onClick={() => testNotification('email')}
                className="bg-purple-600 hover:bg-purple-500 py-2 rounded-lg"
              >
                بريد
              </button>
            </div>
          </div>
        )}
      </div>

      {showConfigModal && selectedProvider && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-xl p-6 w-full max-w-md max-h-[80vh] overflow-auto">
            <h2 className="text-xl font-bold mb-4">
              إعداد {providers[selectedProvider].name}
            </h2>
            <div className="space-y-4">
              {providers[selectedProvider].fields
                .filter(field => !field.showIf || field.showIf(configForm))
                .map(field => (
                  <div key={field.key}>
                    <label className="block text-sm text-gray-400 mb-1">{field.label}</label>
                    {field.type === 'select' ? (
                      <select
                        value={configForm[field.key] || ''}
                        onChange={(e) => setConfigForm({...configForm, [field.key]: e.target.value})}
                        className="w-full bg-gray-700 rounded-lg px-4 py-2"
                      >
                        {field.options.map(opt => (
                          <option key={opt.value} value={opt.value}>{opt.label}</option>
                        ))}
                      </select>
                    ) : (
                      <input
                        type={field.type}
                        value={configForm[field.key] || ''}
                        onChange={(e) => setConfigForm({...configForm, [field.key]: e.target.value})}
                        className="w-full bg-gray-700 rounded-lg px-4 py-2"
                      />
                    )}
                  </div>
                ))}
              
              <div className="flex items-center gap-3 mt-4">
                <input
                  type="checkbox"
                  id="is_active"
                  checked={configForm.is_active ?? true}
                  onChange={(e) => setConfigForm({...configForm, is_active: e.target.checked})}
                  className="w-5 h-5"
                />
                <label htmlFor="is_active">تفعيل الخدمة</label>
              </div>
            </div>
            
            <div className="flex gap-3 mt-6">
              <button
                onClick={saveConfig}
                className="flex-1 bg-green-600 hover:bg-green-500 py-2 rounded-lg"
              >
                حفظ
              </button>
              <button
                onClick={() => setShowConfigModal(false)}
                className="flex-1 bg-gray-600 hover:bg-gray-500 py-2 rounded-lg"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
