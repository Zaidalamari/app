import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios'
import { Users, Package, ShoppingCart, DollarSign, Plus, Wallet, Server, CreditCard, ExternalLink, UserPlus, Gift, Store, Crown, Edit, Trash2, Key, X, Search, Eye, EyeOff, Copy, Check, Bell } from 'lucide-react'

export default function AdminDashboard({ user }) {
  const [stats, setStats] = useState({})
  const [users, setUsers] = useState([])
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [activeTab, setActiveTab] = useState('overview')
  const [showAddProduct, setShowAddProduct] = useState(false)
  const [showAddBalance, setShowAddBalance] = useState(false)
  const [showCodesModal, setShowCodesModal] = useState(false)
  const [showAddCategory, setShowAddCategory] = useState(false)
  const [selectedUser, setSelectedUser] = useState(null)
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [balanceAmount, setBalanceAmount] = useState('')
  const [productSearch, setProductSearch] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  const [newProduct, setNewProduct] = useState({
    name: '', name_ar: '', description: '', image_url: '',
    base_price: '', selling_price: '', distributor_price: '',
    category_id: '', product_type: 'digital', bulk_codes: ''
  })

  const [newCategory, setNewCategory] = useState({ name: '', name_ar: '', description: '', icon: '' })
  const [newCode, setNewCode] = useState({ code: '', serial_number: '' })
  const [bulkCodesText, setBulkCodesText] = useState('')
  const [codesTab, setCodesTab] = useState('view')
  const [productCodes, setProductCodes] = useState([])
  const [codesCount, setCodesCount] = useState({ available: 0, sold: 0, total: 0 })

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/')
      return
    }
    fetchData()
  }, [user])

  useEffect(() => {
    if (activeTab === 'products') {
      fetchProducts()
      fetchCategories()
    }
  }, [activeTab, productSearch])

  const fetchData = async () => {
    const token = localStorage.getItem('token')
    const config = { headers: { Authorization: `Bearer ${token}` } }

    try {
      const [statsRes, usersRes] = await Promise.all([
        axios.get('/api/admin/dashboard', config),
        axios.get('/api/admin/users', config)
      ])
      setStats(statsRes.data.data || {})
      setUsers(usersRes.data.data || [])
    } catch (err) {
      console.error(err)
    }
  }

  const fetchProducts = async () => {
    const token = localStorage.getItem('token')
    try {
      const res = await axios.get('/api/admin/products', {
        headers: { Authorization: `Bearer ${token}` },
        params: { search: productSearch, limit: 50 }
      })
      setProducts(res.data.data || [])
    } catch (err) {
      console.error(err)
    }
  }

  const fetchCategories = async () => {
    const token = localStorage.getItem('token')
    try {
      const res = await axios.get('/api/admin/categories', {
        headers: { Authorization: `Bearer ${token}` }
      })
      setCategories(res.data.data || [])
    } catch (err) {
      console.error(err)
    }
  }

  const fetchProductCodes = async (productId) => {
    const token = localStorage.getItem('token')
    try {
      const res = await axios.get(`/api/admin/products/${productId}/codes`, {
        headers: { Authorization: `Bearer ${token}` },
        params: { limit: 100 }
      })
      setProductCodes(res.data.data || [])
      setCodesCount(res.data.counts || { available: 0, sold: 0, total: 0 })
    } catch (err) {
      console.error(err)
    }
  }

  const addBalance = async () => {
    if (!selectedUser || !balanceAmount) return
    
    const token = localStorage.getItem('token')
    try {
      await axios.post('/api/wallet/add-balance', 
        { user_id: selectedUser.id, amount: parseFloat(balanceAmount) },
        { headers: { Authorization: `Bearer ${token}` } }
      )
      alert('تم إضافة الرصيد بنجاح')
      setShowAddBalance(false)
      setBalanceAmount('')
      fetchData()
    } catch (err) {
      alert(err.response?.data?.message || 'خطأ')
    }
  }

  const createProduct = async () => {
    if (!newProduct.name || !newProduct.base_price || !newProduct.selling_price) {
      alert('يرجى ملء الحقول المطلوبة (الاسم، سعر الشراء، سعر البيع)')
      return
    }

    setLoading(true)
    const token = localStorage.getItem('token')
    try {
      await axios.post('/api/admin/products', {
        ...newProduct,
        base_price: parseFloat(newProduct.base_price),
        selling_price: parseFloat(newProduct.selling_price),
        distributor_price: newProduct.distributor_price ? parseFloat(newProduct.distributor_price) : parseFloat(newProduct.selling_price),
        category_id: newProduct.category_id || null
      }, { headers: { Authorization: `Bearer ${token}` } })
      
      alert('تم إنشاء المنتج بنجاح')
      setShowAddProduct(false)
      setNewProduct({
        name: '', name_ar: '', description: '', image_url: '',
        base_price: '', selling_price: '', distributor_price: '',
        category_id: '', product_type: 'digital', bulk_codes: ''
      })
      fetchProducts()
      fetchData()
    } catch (err) {
      alert(err.response?.data?.message || 'خطأ في إنشاء المنتج')
    } finally {
      setLoading(false)
    }
  }

  const createCategory = async () => {
    if (!newCategory.name) {
      alert('اسم الفئة مطلوب')
      return
    }

    const token = localStorage.getItem('token')
    try {
      await axios.post('/api/admin/categories', newCategory, {
        headers: { Authorization: `Bearer ${token}` }
      })
      alert('تم إنشاء الفئة بنجاح')
      setShowAddCategory(false)
      setNewCategory({ name: '', name_ar: '', description: '', icon: '' })
      fetchCategories()
    } catch (err) {
      alert(err.response?.data?.message || 'خطأ')
    }
  }

  const deleteProduct = async (productId) => {
    if (!confirm('هل أنت متأكد من حذف هذا المنتج؟ سيتم حذف جميع الأكواد المرتبطة به.')) return

    const token = localStorage.getItem('token')
    try {
      await axios.delete(`/api/admin/products/${productId}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      alert('تم حذف المنتج بنجاح')
      fetchProducts()
      fetchData()
    } catch (err) {
      alert(err.response?.data?.message || 'خطأ في حذف المنتج')
    }
  }

  const openCodesModal = (product) => {
    setSelectedProduct(product)
    setShowCodesModal(true)
    setCodesTab('view')
    fetchProductCodes(product.id)
  }

  const addSingleCode = async () => {
    if (!newCode.code.trim()) {
      alert('الكود مطلوب')
      return
    }

    const token = localStorage.getItem('token')
    try {
      await axios.post(`/api/admin/products/${selectedProduct.id}/codes`, newCode, {
        headers: { Authorization: `Bearer ${token}` }
      })
      alert('تم إضافة الكود بنجاح')
      setNewCode({ code: '', serial_number: '' })
      fetchProductCodes(selectedProduct.id)
      fetchProducts()
    } catch (err) {
      alert(err.response?.data?.message || 'خطأ في إضافة الكود')
    }
  }

  const addBulkCodes = async () => {
    if (!bulkCodesText.trim()) {
      alert('يرجى إدخال الأكواد')
      return
    }

    setLoading(true)
    const token = localStorage.getItem('token')
    try {
      const res = await axios.post(`/api/admin/products/${selectedProduct.id}/codes/bulk`, 
        { codes_text: bulkCodesText },
        { headers: { Authorization: `Bearer ${token}` } }
      )
      alert(res.data.message)
      setBulkCodesText('')
      fetchProductCodes(selectedProduct.id)
      fetchProducts()
    } catch (err) {
      alert(err.response?.data?.message || 'خطأ في إضافة الأكواد')
    } finally {
      setLoading(false)
    }
  }

  const deleteCode = async (codeId) => {
    if (!confirm('هل أنت متأكد من حذف هذا الكود؟')) return

    const token = localStorage.getItem('token')
    try {
      await axios.delete(`/api/admin/codes/${codeId}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      fetchProductCodes(selectedProduct.id)
      fetchProducts()
    } catch (err) {
      alert(err.response?.data?.message || 'خطأ في حذف الكود')
    }
  }

  const copyCode = (code) => {
    navigator.clipboard.writeText(code)
  }

  if (!user || user.role !== 'admin') return null

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-purple-700 text-white p-4">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-xl font-bold">لوحة تحكم المشرف</h1>
          <Link to="/" className="hover:underline">العودة للرئيسية</Link>
        </div>
      </nav>

      <div className="container mx-auto p-6">
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <StatCard title="المستخدمين" value={stats.total_users} icon={<Users />} color="blue" />
          <StatCard title="الموزعين" value={stats.total_distributors} icon={<Users />} color="purple" />
          <StatCard title="الطلبات" value={stats.total_orders} icon={<ShoppingCart />} color="green" />
          <StatCard title="الإيرادات" value={`${stats.total_revenue || 0} ر.س`} icon={<DollarSign />} color="yellow" />
        </div>

        <div className="flex flex-wrap gap-4 mb-6">
          <TabBtn active={activeTab === 'overview'} onClick={() => setActiveTab('overview')}>نظرة عامة</TabBtn>
          <TabBtn active={activeTab === 'users'} onClick={() => setActiveTab('users')}>المستخدمين</TabBtn>
          <TabBtn active={activeTab === 'products'} onClick={() => setActiveTab('products')}>المنتجات</TabBtn>
          <TabBtn active={activeTab === 'integrations'} onClick={() => setActiveTab('integrations')}>التكاملات</TabBtn>
          <Link to="/admin/wallets" className="px-6 py-3 rounded-lg font-bold bg-gradient-to-r from-green-500 to-green-600 text-white flex items-center gap-2 hover:from-green-600 hover:to-green-700">
            <Wallet className="w-5 h-5" /> إدارة المحافظ
          </Link>
          <Link to="/admin/currencies" className="px-6 py-3 rounded-lg font-bold bg-gradient-to-r from-teal-500 to-emerald-600 text-white flex items-center gap-2 hover:from-teal-600 hover:to-emerald-700">
            <DollarSign className="w-5 h-5" /> العملات والدول
          </Link>
          <Link to="/admin/smm" className="px-6 py-3 rounded-lg font-bold bg-gradient-to-r from-pink-500 to-rose-600 text-white flex items-center gap-2 hover:from-pink-600 hover:to-rose-700">
            <Server className="w-5 h-5" /> مزودي SMM
          </Link>
          <Link to="/admin/prices" className="px-6 py-3 rounded-lg font-bold bg-gradient-to-r from-amber-500 to-orange-600 text-white flex items-center gap-2 hover:from-amber-600 hover:to-orange-700">
            <DollarSign className="w-5 h-5" /> إدارة الأسعار
          </Link>
          <Link to="/admin/referrals" className="px-6 py-3 rounded-lg font-bold bg-gradient-to-r from-indigo-500 to-purple-600 text-white flex items-center gap-2 hover:from-indigo-600 hover:to-purple-700">
            <Gift className="w-5 h-5" /> نظام الإحالات
          </Link>
          <Link to="/admin/users" className="px-6 py-3 rounded-lg font-bold bg-gradient-to-r from-blue-500 to-cyan-600 text-white flex items-center gap-2 hover:from-blue-600 hover:to-cyan-700">
            <UserPlus className="w-5 h-5" /> إدارة المستخدمين
          </Link>
          <Link to="/admin/subscriptions" className="px-6 py-3 rounded-lg font-bold bg-gradient-to-r from-yellow-500 to-amber-600 text-white flex items-center gap-2 hover:from-yellow-600 hover:to-amber-700">
            <Crown className="w-5 h-5" /> الاشتراكات والقوالب
          </Link>
          <Link to="/admin/gateways" className="px-6 py-3 rounded-lg font-bold bg-gradient-to-r from-orange-500 to-red-600 text-white flex items-center gap-2 hover:from-orange-600 hover:to-red-700">
            <CreditCard className="w-5 h-5" /> بوابات الدفع
          </Link>
          <Link to="/admin/suppliers" className="px-6 py-3 rounded-lg font-bold bg-gradient-to-r from-cyan-500 to-blue-600 text-white flex items-center gap-2 hover:from-cyan-600 hover:to-blue-700">
            <Server className="w-5 h-5" /> الموردين الخارجيين
          </Link>
          <Link to="/admin/notifications" className="px-6 py-3 rounded-lg font-bold bg-gradient-to-r from-emerald-500 to-teal-600 text-white flex items-center gap-2 hover:from-emerald-600 hover:to-teal-700">
            <Bell className="w-5 h-5" /> الإشعارات
          </Link>
          <Link to="/join-seller" className="px-6 py-3 rounded-lg font-bold bg-gradient-to-r from-violet-500 to-fuchsia-600 text-white flex items-center gap-2 hover:from-violet-600 hover:to-fuchsia-700">
            <Store className="w-5 h-5" /> صفحة البائع
          </Link>
        </div>

        {activeTab === 'overview' && (
          <div className="bg-white rounded-xl shadow p-6">
            <h3 className="text-xl font-bold mb-4">ملخص النظام</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="p-4 bg-blue-50 rounded-lg">
                <h4 className="font-bold mb-2">المنتجات النشطة</h4>
                <p className="text-3xl font-bold text-blue-600">{stats.total_products}</p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <h4 className="font-bold mb-2">الأكواد المتوفرة</h4>
                <p className="text-3xl font-bold text-green-600">{stats.available_codes}</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'users' && (
          <div className="bg-white rounded-xl shadow p-6">
            <h3 className="text-xl font-bold mb-4">إدارة المستخدمين</h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="p-3 text-right">الاسم</th>
                    <th className="p-3 text-right">البريد</th>
                    <th className="p-3 text-right">النوع</th>
                    <th className="p-3 text-right">الرصيد</th>
                    <th className="p-3 text-right">الحالة</th>
                    <th className="p-3 text-right">إجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map(u => (
                    <tr key={u.id} className="border-b">
                      <td className="p-3">{u.name}</td>
                      <td className="p-3">{u.email}</td>
                      <td className="p-3">{u.role === 'distributor' ? 'موزع' : 'بائع'}</td>
                      <td className="p-3">{parseFloat(u.balance).toFixed(2)} ر.س</td>
                      <td className="p-3">
                        <span className={`px-2 py-1 rounded ${u.is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                          {u.is_active ? 'نشط' : 'معطل'}
                        </span>
                      </td>
                      <td className="p-3">
                        <button 
                          onClick={() => { setSelectedUser(u); setShowAddBalance(true); }}
                          className="bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600"
                        >
                          <Wallet className="w-4 h-4 inline" /> إضافة رصيد
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'products' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow p-6">
              <div className="flex flex-wrap justify-between items-center gap-4 mb-6">
                <h3 className="text-xl font-bold">إدارة المنتجات</h3>
                <div className="flex gap-3">
                  <button 
                    onClick={() => setShowAddCategory(true)}
                    className="bg-gray-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-gray-700"
                  >
                    <Plus className="w-5 h-5" /> فئة جديدة
                  </button>
                  <button 
                    onClick={() => setShowAddProduct(true)}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700"
                  >
                    <Plus className="w-5 h-5" /> إضافة منتج
                  </button>
                </div>
              </div>

              <div className="relative mb-6">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  placeholder="البحث عن منتج..."
                  className="w-full pr-10 pl-4 py-3 border rounded-lg"
                />
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="p-3 text-right">المنتج</th>
                      <th className="p-3 text-right">الفئة</th>
                      <th className="p-3 text-right">سعر الشراء</th>
                      <th className="p-3 text-right">سعر البيع</th>
                      <th className="p-3 text-right">الأكواد المتوفرة</th>
                      <th className="p-3 text-right">الحالة</th>
                      <th className="p-3 text-right">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map(p => (
                      <tr key={p.id} className="border-b hover:bg-gray-50">
                        <td className="p-3">
                          <div className="flex items-center gap-3">
                            {p.image_url && (
                              <img src={p.image_url} alt={p.name} className="w-10 h-10 object-cover rounded" />
                            )}
                            <div>
                              <p className="font-medium">{p.name_ar || p.name}</p>
                              {p.name_ar && <p className="text-sm text-gray-500">{p.name}</p>}
                            </div>
                          </div>
                        </td>
                        <td className="p-3">{p.category_name_ar || p.category_name || '-'}</td>
                        <td className="p-3">{parseFloat(p.base_price).toFixed(2)} ر.س</td>
                        <td className="p-3">{parseFloat(p.selling_price).toFixed(2)} ر.س</td>
                        <td className="p-3">
                          <span className={`px-2 py-1 rounded ${parseInt(p.available_codes) > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                            {p.available_codes} / {p.total_codes}
                          </span>
                        </td>
                        <td className="p-3">
                          <span className={`px-2 py-1 rounded ${p.is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                            {p.is_active ? 'نشط' : 'معطل'}
                          </span>
                        </td>
                        <td className="p-3">
                          <div className="flex gap-2">
                            <button 
                              onClick={() => openCodesModal(p)}
                              className="bg-blue-500 text-white p-2 rounded hover:bg-blue-600"
                              title="إدارة الأكواد"
                            >
                              <Key className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => deleteProduct(p.id)}
                              className="bg-red-500 text-white p-2 rounded hover:bg-red-600"
                              title="حذف"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {products.length === 0 && (
                      <tr>
                        <td colSpan={7} className="p-6 text-center text-gray-500">
                          لا توجد منتجات. أضف منتجًا جديدًا للبدء.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'integrations' && (
          <div className="space-y-6">
            <h3 className="text-xl font-bold">التكاملات الخارجية</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Link to="/admin/mintroute" className="bg-white rounded-xl shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center">
                    <CreditCard className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg">Alameri Digital</h4>
                    <p className="text-sm text-gray-500">بطاقات رقمية</p>
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-4">
                  استيراد وإدارة البطاقات الرقمية من Alameri Digital API
                </p>
                <div className="flex items-center text-orange-600 text-sm font-medium">
                  <span>إدارة التكامل</span>
                  <ExternalLink className="w-4 h-4 mr-1" />
                </div>
              </Link>

              <Link to="/admin/pressable" className="bg-white rounded-xl shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                    <Server className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg">Pressable</h4>
                    <p className="text-sm text-gray-500">استضافة WordPress</p>
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-4">
                  إدارة مواقع WordPress والاستضافة المُدارة
                </p>
                <div className="flex items-center text-purple-600 text-sm font-medium">
                  <span>إدارة التكامل</span>
                  <ExternalLink className="w-4 h-4 mr-1" />
                </div>
              </Link>
            </div>
          </div>
        )}

        {showAddBalance && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-6 w-full max-w-md">
              <h3 className="text-xl font-bold mb-4">إضافة رصيد لـ {selectedUser?.name}</h3>
              <input
                type="number"
                value={balanceAmount}
                onChange={(e) => setBalanceAmount(e.target.value)}
                placeholder="المبلغ"
                className="w-full p-4 border rounded-lg mb-4"
              />
              <div className="flex gap-4">
                <button onClick={addBalance} className="flex-1 bg-green-600 text-white py-3 rounded-lg">إضافة</button>
                <button onClick={() => setShowAddBalance(false)} className="flex-1 bg-gray-300 py-3 rounded-lg">إلغاء</button>
              </div>
            </div>
          </div>
        )}

        {showAddProduct && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 overflow-y-auto p-4">
            <div className="bg-white rounded-xl p-6 w-full max-w-2xl my-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold">إضافة منتج جديد</h3>
                <button onClick={() => setShowAddProduct(false)} className="text-gray-500 hover:text-gray-700">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="grid md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium mb-1">اسم المنتج (عربي) *</label>
                  <input
                    type="text"
                    value={newProduct.name_ar}
                    onChange={(e) => setNewProduct({...newProduct, name_ar: e.target.value, name: newProduct.name || e.target.value})}
                    className="w-full p-3 border rounded-lg"
                    placeholder="بطاقة شحن 50 ريال"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">اسم المنتج (انجليزي)</label>
                  <input
                    type="text"
                    value={newProduct.name}
                    onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
                    className="w-full p-3 border rounded-lg"
                    placeholder="50 SAR Card"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium mb-1">الفئة</label>
                  <select
                    value={newProduct.category_id}
                    onChange={(e) => setNewProduct({...newProduct, category_id: e.target.value})}
                    className="w-full p-3 border rounded-lg"
                  >
                    <option value="">بدون فئة</option>
                    {categories.map(c => (
                      <option key={c.id} value={c.id}>{c.name_ar || c.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">رابط الصورة</label>
                  <input
                    type="url"
                    value={newProduct.image_url}
                    onChange={(e) => setNewProduct({...newProduct, image_url: e.target.value})}
                    className="w-full p-3 border rounded-lg"
                    placeholder="https://..."
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium mb-1">سعر الشراء (التكلفة) *</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newProduct.base_price}
                    onChange={(e) => setNewProduct({...newProduct, base_price: e.target.value})}
                    className="w-full p-3 border rounded-lg"
                    placeholder="40"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">سعر البيع *</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newProduct.selling_price}
                    onChange={(e) => setNewProduct({...newProduct, selling_price: e.target.value})}
                    className="w-full p-3 border rounded-lg"
                    placeholder="50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">سعر الموزع</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newProduct.distributor_price}
                    onChange={(e) => setNewProduct({...newProduct, distributor_price: e.target.value})}
                    className="w-full p-3 border rounded-lg"
                    placeholder="45"
                  />
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium mb-1">الوصف</label>
                <textarea
                  value={newProduct.description}
                  onChange={(e) => setNewProduct({...newProduct, description: e.target.value})}
                  className="w-full p-3 border rounded-lg"
                  rows={2}
                  placeholder="وصف المنتج..."
                />
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium mb-2">
                  أكواد المنتج (اختياري - يمكنك إضافتها لاحقاً)
                </label>
                <p className="text-sm text-gray-500 mb-2">
                  أدخل كل كود في سطر منفصل. للأكواد مع رقم تسلسلي استخدم: الكود|الرقم_التسلسلي
                </p>
                <textarea
                  value={newProduct.bulk_codes}
                  onChange={(e) => setNewProduct({...newProduct, bulk_codes: e.target.value})}
                  className="w-full p-3 border rounded-lg font-mono text-sm"
                  rows={5}
                  placeholder="XXXX-XXXX-XXXX-XXXX
YYYY-YYYY-YYYY-YYYY|SN123456
ZZZZ-ZZZZ-ZZZZ-ZZZZ"
                  dir="ltr"
                />
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={createProduct} 
                  disabled={loading}
                  className="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  {loading ? 'جاري الإنشاء...' : 'إنشاء المنتج'}
                </button>
                <button 
                  onClick={() => setShowAddProduct(false)} 
                  className="flex-1 bg-gray-300 py-3 rounded-lg hover:bg-gray-400"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        )}

        {showAddCategory && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-6 w-full max-w-md">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold">إضافة فئة جديدة</h3>
                <button onClick={() => setShowAddCategory(false)} className="text-gray-500">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-4">
                <input
                  type="text"
                  value={newCategory.name}
                  onChange={(e) => setNewCategory({...newCategory, name: e.target.value})}
                  placeholder="اسم الفئة (انجليزي) *"
                  className="w-full p-3 border rounded-lg"
                />
                <input
                  type="text"
                  value={newCategory.name_ar}
                  onChange={(e) => setNewCategory({...newCategory, name_ar: e.target.value})}
                  placeholder="اسم الفئة (عربي)"
                  className="w-full p-3 border rounded-lg"
                />
                <input
                  type="text"
                  value={newCategory.icon}
                  onChange={(e) => setNewCategory({...newCategory, icon: e.target.value})}
                  placeholder="أيقونة (emoji أو رابط)"
                  className="w-full p-3 border rounded-lg"
                />
              </div>

              <div className="flex gap-4 mt-6">
                <button onClick={createCategory} className="flex-1 bg-blue-600 text-white py-3 rounded-lg">إنشاء</button>
                <button onClick={() => setShowAddCategory(false)} className="flex-1 bg-gray-300 py-3 rounded-lg">إلغاء</button>
              </div>
            </div>
          </div>
        )}

        {showCodesModal && selectedProduct && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 overflow-y-auto p-4">
            <div className="bg-white rounded-xl p-6 w-full max-w-3xl my-8">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h3 className="text-xl font-bold">إدارة الأكواد</h3>
                  <p className="text-gray-500">{selectedProduct.name_ar || selectedProduct.name}</p>
                </div>
                <button onClick={() => setShowCodesModal(false)} className="text-gray-500 hover:text-gray-700">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="bg-green-50 p-4 rounded-lg text-center">
                  <p className="text-2xl font-bold text-green-600">{codesCount.available}</p>
                  <p className="text-sm text-gray-600">متوفر</p>
                </div>
                <div className="bg-red-50 p-4 rounded-lg text-center">
                  <p className="text-2xl font-bold text-red-600">{codesCount.sold}</p>
                  <p className="text-sm text-gray-600">مباع</p>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg text-center">
                  <p className="text-2xl font-bold text-blue-600">{codesCount.total}</p>
                  <p className="text-sm text-gray-600">الإجمالي</p>
                </div>
              </div>

              <div className="flex gap-2 mb-6">
                <button
                  onClick={() => setCodesTab('view')}
                  className={`px-4 py-2 rounded-lg ${codesTab === 'view' ? 'bg-blue-600 text-white' : 'bg-gray-100'}`}
                >
                  عرض الأكواد
                </button>
                <button
                  onClick={() => setCodesTab('single')}
                  className={`px-4 py-2 rounded-lg ${codesTab === 'single' ? 'bg-blue-600 text-white' : 'bg-gray-100'}`}
                >
                  إضافة كود فردي
                </button>
                <button
                  onClick={() => setCodesTab('bulk')}
                  className={`px-4 py-2 rounded-lg ${codesTab === 'bulk' ? 'bg-blue-600 text-white' : 'bg-gray-100'}`}
                >
                  إضافة أكواد جماعية
                </button>
              </div>

              {codesTab === 'view' && (
                <div className="max-h-96 overflow-y-auto">
                  {productCodes.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">لا توجد أكواد. أضف أكوادًا للبدء.</p>
                  ) : (
                    <table className="w-full text-sm">
                      <thead className="bg-gray-100 sticky top-0">
                        <tr>
                          <th className="p-2 text-right">الكود</th>
                          <th className="p-2 text-right">الرقم التسلسلي</th>
                          <th className="p-2 text-right">الحالة</th>
                          <th className="p-2 text-right">إجراءات</th>
                        </tr>
                      </thead>
                      <tbody>
                        {productCodes.map(code => (
                          <tr key={code.id} className="border-b">
                            <td className="p-2 font-mono text-xs" dir="ltr">
                              {code.code.length > 30 ? code.code.substring(0, 30) + '...' : code.code}
                            </td>
                            <td className="p-2 text-gray-500">{code.serial_number || '-'}</td>
                            <td className="p-2">
                              <span className={`px-2 py-1 rounded text-xs ${code.is_sold ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                                {code.is_sold ? 'مباع' : 'متوفر'}
                              </span>
                            </td>
                            <td className="p-2">
                              <div className="flex gap-1">
                                <button
                                  onClick={() => copyCode(code.code)}
                                  className="p-1 text-gray-500 hover:text-blue-600"
                                  title="نسخ"
                                >
                                  <Copy className="w-4 h-4" />
                                </button>
                                {!code.is_sold && (
                                  <button
                                    onClick={() => deleteCode(code.id)}
                                    className="p-1 text-gray-500 hover:text-red-600"
                                    title="حذف"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              )}

              {codesTab === 'single' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">الكود *</label>
                    <input
                      type="text"
                      value={newCode.code}
                      onChange={(e) => setNewCode({...newCode, code: e.target.value})}
                      className="w-full p-3 border rounded-lg font-mono"
                      placeholder="XXXX-XXXX-XXXX-XXXX"
                      dir="ltr"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">الرقم التسلسلي (اختياري)</label>
                    <input
                      type="text"
                      value={newCode.serial_number}
                      onChange={(e) => setNewCode({...newCode, serial_number: e.target.value})}
                      className="w-full p-3 border rounded-lg"
                      placeholder="SN123456"
                    />
                  </div>
                  <button
                    onClick={addSingleCode}
                    className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700"
                  >
                    إضافة الكود
                  </button>
                </div>
              )}

              {codesTab === 'bulk' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">الأكواد (كل كود في سطر)</label>
                    <p className="text-sm text-gray-500 mb-2">
                      للأكواد مع رقم تسلسلي، استخدم: الكود|الرقم_التسلسلي
                    </p>
                    <textarea
                      value={bulkCodesText}
                      onChange={(e) => setBulkCodesText(e.target.value)}
                      className="w-full p-3 border rounded-lg font-mono text-sm"
                      rows={8}
                      placeholder="XXXX-XXXX-XXXX-XXXX
YYYY-YYYY-YYYY-YYYY|SN123456
ZZZZ-ZZZZ-ZZZZ-ZZZZ"
                      dir="ltr"
                    />
                  </div>
                  <div className="text-sm text-gray-500">
                    عدد الأكواد: {bulkCodesText.split('\n').filter(l => l.trim()).length}
                  </div>
                  <button
                    onClick={addBulkCodes}
                    disabled={loading}
                    className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 disabled:opacity-50"
                  >
                    {loading ? 'جاري الإضافة...' : 'إضافة الأكواد'}
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function StatCard({ title, value, icon, color }) {
  const colors = {
    blue: 'from-blue-500 to-blue-600',
    purple: 'from-purple-500 to-purple-600',
    green: 'from-green-500 to-green-600',
    yellow: 'from-yellow-500 to-orange-500'
  }
  
  return (
    <div className={`bg-gradient-to-r ${colors[color]} rounded-xl p-6 text-white`}>
      <div className="flex justify-between">
        <div>
          <p className="opacity-80">{title}</p>
          <p className="text-3xl font-bold">{value || 0}</p>
        </div>
        <div className="opacity-50">{icon}</div>
      </div>
    </div>
  )
}

function TabBtn({ children, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`px-6 py-3 rounded-lg font-bold ${active ? 'bg-purple-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-100'}`}
    >
      {children}
    </button>
  )
}
