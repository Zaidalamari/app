import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

export default function AdminSuppliers() {
  const [suppliers, setSuppliers] = useState([]);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showOrdersModal, setShowOrdersModal] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    host: '',
    username: '',
    password: ''
  });
  const [editingId, setEditingId] = useState(null);
  const [testResult, setTestResult] = useState(null);

  const token = localStorage.getItem('token');

  const fetchSuppliers = async () => {
    try {
      const res = await fetch('/api/supplier/list', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setSuppliers(data.suppliers || []);
      }
    } catch (error) {
      console.error('Error fetching suppliers:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchOrders = async () => {
    try {
      const res = await fetch('/api/supplier/orders', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setOrders(data.orders || []);
      }
    } catch (error) {
      console.error('Error fetching orders:', error);
    }
  };

  useEffect(() => {
    fetchSuppliers();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const url = editingId ? `/api/supplier/${editingId}` : '/api/supplier/add';
      const method = editingId ? 'PUT' : 'POST';
      
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(formData)
      });
      
      const data = await res.json();
      
      if (data.success) {
        setShowAddModal(false);
        setFormData({ name: '', host: '', username: '', password: '' });
        setEditingId(null);
        fetchSuppliers();
      } else {
        alert(data.message);
      }
    } catch (error) {
      console.error('Error saving supplier:', error);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('هل أنت متأكد من حذف هذا المورد؟')) return;
    
    try {
      const res = await fetch(`/api/supplier/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      const data = await res.json();
      if (data.success) {
        fetchSuppliers();
      }
    } catch (error) {
      console.error('Error deleting supplier:', error);
    }
  };

  const handleTest = async (id) => {
    setTestResult({ loading: true, id });
    
    try {
      const res = await fetch(`/api/supplier/test/${id}`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      const data = await res.json();
      setTestResult({ ...data, id });
    } catch (error) {
      setTestResult({ success: false, message: 'فشل الاتصال', id });
    }
  };

  const handleEdit = (supplier) => {
    setFormData({
      name: supplier.name,
      host: supplier.host,
      username: supplier.username,
      password: ''
    });
    setEditingId(supplier.id);
    setShowAddModal(true);
  };

  const viewOrders = () => {
    fetchOrders();
    setShowOrdersModal(true);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white" dir="rtl">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold">إدارة الموردين</h1>
            <p className="text-gray-400 mt-2">ربط لوحات الموردين الخارجية للطلبات التلقائية</p>
          </div>
          <div className="flex gap-4">
            <Link to="/admin" className="bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded-lg">
              العودة للوحة
            </Link>
            <button
              onClick={viewOrders}
              className="bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded-lg"
            >
              سجل الطلبات
            </button>
            <button
              onClick={() => {
                setFormData({ name: '', host: '', username: '', password: '' });
                setEditingId(null);
                setShowAddModal(true);
              }}
              className="bg-green-600 hover:bg-green-500 px-4 py-2 rounded-lg"
            >
              + إضافة مورد
            </button>
          </div>
        </div>

        <div className="bg-gray-800 rounded-xl p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">كيفية الربط</h2>
          <div className="bg-gray-700 rounded-lg p-4 text-sm">
            <p className="mb-2">لربط لوحة IPTV ActiveCode، أدخل البيانات التالية:</p>
            <ul className="list-disc list-inside space-y-1 text-gray-300">
              <li><strong>الاسم:</strong> اسم المورد للتمييز</li>
              <li><strong>الرابط (Host):</strong> مثال: http://smarters.info:80</li>
              <li><strong>اسم المستخدم:</strong> من بيانات اللوحة (مثال: 68990008766)</li>
              <li><strong>كلمة المرور:</strong> من بيانات اللوحة (مثال: NLVCAnyexx)</li>
            </ul>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-500 mx-auto"></div>
          </div>
        ) : suppliers.length === 0 ? (
          <div className="bg-gray-800 rounded-xl p-12 text-center">
            <div className="text-6xl mb-4">🔌</div>
            <h3 className="text-xl font-semibold mb-2">لا يوجد موردين</h3>
            <p className="text-gray-400">أضف مورداً لربط الطلبات التلقائية</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {suppliers.map(supplier => (
              <div key={supplier.id} className="bg-gray-800 rounded-xl p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-xl font-semibold">{supplier.name}</h3>
                      <span className={`px-2 py-1 rounded text-xs ${supplier.is_active ? 'bg-green-600' : 'bg-red-600'}`}>
                        {supplier.is_active ? 'نشط' : 'معطل'}
                      </span>
                    </div>
                    <p className="text-gray-400 text-sm mb-1">الرابط: {supplier.host}</p>
                    <p className="text-gray-400 text-sm mb-1">اسم المستخدم: {supplier.username}</p>
                    <p className="text-gray-400 text-sm">
                      آخر مزامنة: {supplier.last_sync ? new Date(supplier.last_sync).toLocaleString('ar') : 'لم تتم المزامنة'}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleTest(supplier.id)}
                      className="bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded-lg text-sm"
                    >
                      {testResult?.loading && testResult?.id === supplier.id ? '...' : 'اختبار'}
                    </button>
                    <button
                      onClick={() => handleEdit(supplier)}
                      className="bg-yellow-600 hover:bg-yellow-500 px-4 py-2 rounded-lg text-sm"
                    >
                      تعديل
                    </button>
                    <button
                      onClick={() => handleDelete(supplier.id)}
                      className="bg-red-600 hover:bg-red-500 px-4 py-2 rounded-lg text-sm"
                    >
                      حذف
                    </button>
                  </div>
                </div>
                
                {testResult && testResult.id === supplier.id && !testResult.loading && (
                  <div className={`mt-4 p-3 rounded-lg ${testResult.success ? 'bg-green-900/50' : 'bg-red-900/50'}`}>
                    {testResult.success ? '✅ ' : '❌ '}
                    {testResult.message}
                    {testResult.info && (
                      <div className="mt-2 text-sm text-gray-300">
                        <p>المستخدم: {testResult.info.username}</p>
                        <p>الحالة: {testResult.info.status}</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-xl p-6 w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">{editingId ? 'تعديل المورد' : 'إضافة مورد جديد'}</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">اسم المورد</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full bg-gray-700 rounded-lg px-4 py-2"
                  required
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">الرابط (Host)</label>
                <input
                  type="text"
                  value={formData.host}
                  onChange={(e) => setFormData({...formData, host: e.target.value})}
                  className="w-full bg-gray-700 rounded-lg px-4 py-2"
                  placeholder="http://smarters.info:80"
                  required
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">اسم المستخدم</label>
                <input
                  type="text"
                  value={formData.username}
                  onChange={(e) => setFormData({...formData, username: e.target.value})}
                  className="w-full bg-gray-700 rounded-lg px-4 py-2"
                  required
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">كلمة المرور</label>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                  className="w-full bg-gray-700 rounded-lg px-4 py-2"
                  required={!editingId}
                  placeholder={editingId ? 'اتركه فارغاً للإبقاء' : ''}
                />
              </div>
              <div className="flex gap-3 mt-6">
                <button type="submit" className="flex-1 bg-green-600 hover:bg-green-500 py-2 rounded-lg">
                  {editingId ? 'تحديث' : 'إضافة'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-gray-600 hover:bg-gray-500 py-2 rounded-lg"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showOrdersModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-xl p-6 w-full max-w-4xl max-h-[80vh] overflow-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">سجل طلبات المورد</h2>
              <button
                onClick={() => setShowOrdersModal(false)}
                className="text-gray-400 hover:text-white text-2xl"
              >
                ✕
              </button>
            </div>
            
            {orders.length === 0 ? (
              <p className="text-center text-gray-400 py-8">لا توجد طلبات</p>
            ) : (
              <div className="space-y-3">
                {orders.map(order => {
                  const credentials = order.credentials ? JSON.parse(order.credentials) : null;
                  return (
                    <div key={order.id} className="bg-gray-700 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <p className="font-semibold">{order.user_name || 'مستخدم'}</p>
                          <p className="text-sm text-gray-400">{order.user_email}</p>
                        </div>
                        <span className={`px-2 py-1 rounded text-xs ${
                          order.status === 'completed' ? 'bg-green-600' : 
                          order.status === 'failed' ? 'bg-red-600' : 'bg-yellow-600'
                        }`}>
                          {order.status === 'completed' ? 'مكتمل' : 
                           order.status === 'failed' ? 'فشل' : 'قيد التنفيذ'}
                        </span>
                      </div>
                      {credentials && (
                        <div className="bg-gray-800 rounded p-3 text-sm mt-2">
                          <p>المستخدم: <code className="text-green-400">{credentials.username}</code></p>
                          <p>كلمة المرور: <code className="text-green-400">{credentials.password}</code></p>
                          <p className="text-xs text-gray-400 mt-1 break-all">{credentials.m3u_url}</p>
                        </div>
                      )}
                      <p className="text-xs text-gray-500 mt-2">
                        {new Date(order.created_at).toLocaleString('ar')}
                      </p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
