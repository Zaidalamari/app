import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'
import { ShoppingCart, Search, Plus, Key, Trash2, X, Copy } from 'lucide-react'
import CountrySelector, { useCountry } from '../components/CountrySelector'

export default function Products({ user }) {
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [selectedCategory, setSelectedCategory] = useState('')
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [purchasing, setPurchasing] = useState(null)
  const { country, setCountry, formatPrice } = useCountry()

  const [showAddProduct, setShowAddProduct] = useState(false)
  const [showAddCategory, setShowAddCategory] = useState(false)
  const [showCodesModal, setShowCodesModal] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [codesTab, setCodesTab] = useState('view')
  const [productCodes, setProductCodes] = useState([])
  const [codesCount, setCodesCount] = useState({ available: 0, sold: 0, total: 0 })
  const [submitting, setSubmitting] = useState(false)

  const [newProduct, setNewProduct] = useState({
    name: '', name_ar: '', description: '', image_url: '',
    base_price: '', selling_price: '', distributor_price: '',
    category_id: '', product_type: 'digital', bulk_codes: ''
  })

  const [newCategory, setNewCategory] = useState({ name: '', name_ar: '', description: '', icon: '' })
  const [newCode, setNewCode] = useState({ code: '', serial_number: '' })
  const [bulkCodesText, setBulkCodesText] = useState('')

  const isAdmin = user?.role === 'admin'

  useEffect(() => {
    fetchProducts()
    fetchCategories()
  }, [selectedCategory, search])

  const fetchProducts = async () => {
    try {
      const params = new URLSearchParams()
      if (selectedCategory) params.append('category_id', selectedCategory)
      if (search) params.append('search', search)
      
      const res = await axios.get(`/api/products?${params}`)
      setProducts(res.data.data || [])
    } catch (err) {
      console.error(err)
    }
    setLoading(false)
  }

  const fetchCategories = async () => {
    try {
      const res = await axios.get('/api/products/categories')
      setCategories(res.data.data || [])
    } catch (err) {
      console.error(err)
    }
  }

  const fetchProductCodes = async (productId) => {
    const token = localStorage.getItem('token')
    try {
      const res = await axios.get(`/api/admin/products/${productId}/codes`, {
        headers: { Authorization: `Bearer ${token}` },
        params: { limit: 100 }
      })
      setProductCodes(res.data.data || [])
      setCodesCount(res.data.counts || { available: 0, sold: 0, total: 0 })
    } catch (err) {
      console.error(err)
    }
  }

  const handlePurchase = async (productId) => {
    if (!user) {
      alert('يجب تسجيل الدخول أولاً')
      return
    }

    setPurchasing(productId)
    const token = localStorage.getItem('token')
    
    try {
      const res = await axios.post('/api/orders/purchase', 
        { product_id: productId, quantity: 1 },
        { headers: { Authorization: `Bearer ${token}` } }
      )
      
      if (res.data.success) {
        alert(`تم الشراء بنجاح!\n\nالكود: ${res.data.data.codes[0]?.code || 'N/A'}`)
        fetchProducts()
      }
    } catch (err) {
      alert(err.response?.data?.message || 'خطأ في الشراء')
    }
    setPurchasing(null)
  }

  const createProduct = async () => {
    if (!newProduct.name || !newProduct.base_price || !newProduct.selling_price) {
      alert('يرجى ملء الحقول المطلوبة (الاسم، سعر الشراء، سعر البيع)')
      return
    }

    setSubmitting(true)
    const token = localStorage.getItem('token')
    try {
      await axios.post('/api/admin/products', {
        ...newProduct,
        base_price: parseFloat(newProduct.base_price),
        selling_price: parseFloat(newProduct.selling_price),
        distributor_price: newProduct.distributor_price ? parseFloat(newProduct.distributor_price) : parseFloat(newProduct.selling_price),
        category_id: newProduct.category_id || null
      }, { headers: { Authorization: `Bearer ${token}` } })
      
      alert('تم إنشاء المنتج بنجاح')
      setShowAddProduct(false)
      setNewProduct({
        name: '', name_ar: '', description: '', image_url: '',
        base_price: '', selling_price: '', distributor_price: '',
        category_id: '', product_type: 'digital', bulk_codes: ''
      })
      fetchProducts()
    } catch (err) {
      alert(err.response?.data?.message || 'خطأ في إنشاء المنتج')
    } finally {
      setSubmitting(false)
    }
  }

  const createCategory = async () => {
    if (!newCategory.name) {
      alert('اسم الفئة مطلوب')
      return
    }

    const token = localStorage.getItem('token')
    try {
      await axios.post('/api/admin/categories', newCategory, {
        headers: { Authorization: `Bearer ${token}` }
      })
      alert('تم إنشاء الفئة بنجاح')
      setShowAddCategory(false)
      setNewCategory({ name: '', name_ar: '', description: '', icon: '' })
      fetchCategories()
    } catch (err) {
      alert(err.response?.data?.message || 'خطأ')
    }
  }

  const deleteProduct = async (productId) => {
    if (!confirm('هل أنت متأكد من حذف هذا المنتج؟ سيتم حذف جميع الأكواد المرتبطة به.')) return

    const token = localStorage.getItem('token')
    try {
      await axios.delete(`/api/admin/products/${productId}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      alert('تم حذف المنتج بنجاح')
      fetchProducts()
    } catch (err) {
      alert(err.response?.data?.message || 'خطأ في حذف المنتج')
    }
  }

  const openCodesModal = (product) => {
    setSelectedProduct(product)
    setShowCodesModal(true)
    setCodesTab('view')
    fetchProductCodes(product.id)
  }

  const addSingleCode = async () => {
    if (!newCode.code.trim()) {
      alert('الكود مطلوب')
      return
    }

    const token = localStorage.getItem('token')
    try {
      await axios.post(`/api/admin/products/${selectedProduct.id}/codes`, newCode, {
        headers: { Authorization: `Bearer ${token}` }
      })
      alert('تم إضافة الكود بنجاح')
      setNewCode({ code: '', serial_number: '' })
      fetchProductCodes(selectedProduct.id)
      fetchProducts()
    } catch (err) {
      alert(err.response?.data?.message || 'خطأ في إضافة الكود')
    }
  }

  const addBulkCodes = async () => {
    if (!bulkCodesText.trim()) {
      alert('يرجى إدخال الأكواد')
      return
    }

    setSubmitting(true)
    const token = localStorage.getItem('token')
    try {
      const res = await axios.post(`/api/admin/products/${selectedProduct.id}/codes/bulk`, 
        { codes_text: bulkCodesText },
        { headers: { Authorization: `Bearer ${token}` } }
      )
      alert(res.data.message)
      setBulkCodesText('')
      fetchProductCodes(selectedProduct.id)
      fetchProducts()
    } catch (err) {
      alert(err.response?.data?.message || 'خطأ في إضافة الأكواد')
    } finally {
      setSubmitting(false)
    }
  }

  const deleteCode = async (codeId) => {
    if (!confirm('هل أنت متأكد من حذف هذا الكود؟')) return

    const token = localStorage.getItem('token')
    try {
      await axios.delete(`/api/admin/codes/${codeId}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      fetchProductCodes(selectedProduct.id)
      fetchProducts()
    } catch (err) {
      alert(err.response?.data?.message || 'خطأ في حذف الكود')
    }
  }

  const copyCode = (code) => {
    navigator.clipboard.writeText(code)
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-gradient-to-r from-blue-600 to-purple-700 text-white shadow-lg p-4">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Link to="/" className="text-2xl font-bold">DigiCards</Link>
            <CountrySelector onCountryChange={setCountry} />
          </div>
          <div className="flex items-center gap-4">
            {user ? (
              <>
                <Link to="/dashboard" className="hover:text-blue-200">لوحة التحكم</Link>
                {isAdmin && <Link to="/admin" className="hover:text-blue-200">مدير النظام</Link>}
                <span className="text-blue-100">{user.name}</span>
              </>
            ) : (
              <Link to="/login" className="bg-white text-blue-600 px-4 py-2 rounded-lg hover:bg-blue-100">تسجيل الدخول</Link>
            )}
          </div>
        </div>
      </nav>

      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold">المنتجات</h2>
          {isAdmin && (
            <div className="flex gap-3">
              <button 
                onClick={() => setShowAddCategory(true)}
                className="bg-gray-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-gray-700"
              >
                <Plus className="w-5 h-5" /> فئة جديدة
              </button>
              <button 
                onClick={() => setShowAddProduct(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700"
              >
                <Plus className="w-5 h-5" /> إضافة منتج
              </button>
            </div>
          )}
        </div>

        <div className="flex flex-wrap gap-4 mb-8">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="ابحث عن منتج..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pr-12 p-4 border rounded-xl focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="p-4 border rounded-xl focus:ring-2 focus:ring-blue-500"
          >
            <option value="">جميع الفئات</option>
            {categories.map(cat => (
              <option key={cat.id} value={cat.id}>{cat.icon} {cat.name_ar || cat.name}</option>
            ))}
          </select>
        </div>

        {loading ? (
          <div className="text-center py-20">
            <div className="text-xl text-gray-500">جاري التحميل...</div>
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-xl text-gray-500">لا توجد منتجات متاحة</div>
            {isAdmin && (
              <button 
                onClick={() => setShowAddProduct(true)}
                className="mt-4 bg-blue-600 text-white px-6 py-3 rounded-lg"
              >
                إضافة منتج جديد
              </button>
            )}
          </div>
        ) : (
          <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.map(product => (
              <div key={product.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition">
                <div className="h-48 bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center relative">
                  {product.image_url ? (
                    <img src={product.image_url} alt={product.name} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-6xl">🎮</span>
                  )}
                  {isAdmin && (
                    <div className="absolute top-2 left-2 flex gap-1">
                      <button
                        onClick={() => openCodesModal(product)}
                        className="bg-blue-500 text-white p-2 rounded-lg hover:bg-blue-600"
                        title="إدارة الأكواد"
                      >
                        <Key className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => deleteProduct(product.id)}
                        className="bg-red-500 text-white p-2 rounded-lg hover:bg-red-600"
                        title="حذف"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-2">{product.name_ar || product.name}</h3>
                  <p className="text-gray-500 text-sm mb-3">{product.category_name}</p>
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-2xl font-bold text-green-600">{formatPrice(product.selling_price)}</span>
                    <span className={`text-sm px-2 py-1 rounded ${product.available_stock > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                      {product.available_stock > 0 ? `متوفر (${product.available_stock})` : 'نفذ'}
                    </span>
                  </div>
                  <button
                    onClick={() => handlePurchase(product.id)}
                    disabled={purchasing === product.id || product.available_stock === 0}
                    className="w-full bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    <ShoppingCart className="w-5 h-5" />
                    {purchasing === product.id ? 'جاري الشراء...' : 'شراء الآن'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showAddProduct && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 overflow-y-auto p-4">
          <div className="bg-white rounded-xl p-6 w-full max-w-2xl my-8">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold">إضافة منتج جديد</h3>
              <button onClick={() => setShowAddProduct(false)} className="text-gray-500 hover:text-gray-700">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-1">اسم المنتج (عربي) *</label>
                <input
                  type="text"
                  value={newProduct.name_ar}
                  onChange={(e) => setNewProduct({...newProduct, name_ar: e.target.value, name: newProduct.name || e.target.value})}
                  className="w-full p-3 border rounded-lg"
                  placeholder="بطاقة شحن 50 ريال"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">اسم المنتج (انجليزي)</label>
                <input
                  type="text"
                  value={newProduct.name}
                  onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
                  className="w-full p-3 border rounded-lg"
                  placeholder="50 SAR Card"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-1">الفئة</label>
                <select
                  value={newProduct.category_id}
                  onChange={(e) => setNewProduct({...newProduct, category_id: e.target.value})}
                  className="w-full p-3 border rounded-lg"
                >
                  <option value="">بدون فئة</option>
                  {categories.map(c => (
                    <option key={c.id} value={c.id}>{c.name_ar || c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">رابط الصورة</label>
                <input
                  type="url"
                  value={newProduct.image_url}
                  onChange={(e) => setNewProduct({...newProduct, image_url: e.target.value})}
                  className="w-full p-3 border rounded-lg"
                  placeholder="https://..."
                />
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-1">سعر الشراء (التكلفة) *</label>
                <input
                  type="number"
                  step="0.01"
                  value={newProduct.base_price}
                  onChange={(e) => setNewProduct({...newProduct, base_price: e.target.value})}
                  className="w-full p-3 border rounded-lg"
                  placeholder="40"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">سعر البيع *</label>
                <input
                  type="number"
                  step="0.01"
                  value={newProduct.selling_price}
                  onChange={(e) => setNewProduct({...newProduct, selling_price: e.target.value})}
                  className="w-full p-3 border rounded-lg"
                  placeholder="50"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">سعر الموزع</label>
                <input
                  type="number"
                  step="0.01"
                  value={newProduct.distributor_price}
                  onChange={(e) => setNewProduct({...newProduct, distributor_price: e.target.value})}
                  className="w-full p-3 border rounded-lg"
                  placeholder="45"
                />
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium mb-1">الوصف</label>
              <textarea
                value={newProduct.description}
                onChange={(e) => setNewProduct({...newProduct, description: e.target.value})}
                className="w-full p-3 border rounded-lg"
                rows={2}
                placeholder="وصف المنتج..."
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">
                أكواد المنتج (اختياري - يمكنك إضافتها لاحقاً)
              </label>
              <p className="text-sm text-gray-500 mb-2">
                أدخل كل كود في سطر منفصل. للأكواد مع رقم تسلسلي استخدم: الكود|الرقم_التسلسلي
              </p>
              <textarea
                value={newProduct.bulk_codes}
                onChange={(e) => setNewProduct({...newProduct, bulk_codes: e.target.value})}
                className="w-full p-3 border rounded-lg font-mono text-sm"
                rows={5}
                placeholder="XXXX-XXXX-XXXX-XXXX
YYYY-YYYY-YYYY-YYYY|SN123456
ZZZZ-ZZZZ-ZZZZ-ZZZZ"
                dir="ltr"
              />
            </div>

            <div className="flex gap-4">
              <button 
                onClick={createProduct} 
                disabled={submitting}
                className="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                {submitting ? 'جاري الإنشاء...' : 'إنشاء المنتج'}
              </button>
              <button 
                onClick={() => setShowAddProduct(false)} 
                className="flex-1 bg-gray-300 py-3 rounded-lg hover:bg-gray-400"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {showAddCategory && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold">إضافة فئة جديدة</h3>
              <button onClick={() => setShowAddCategory(false)} className="text-gray-500">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-4">
              <input
                type="text"
                value={newCategory.name}
                onChange={(e) => setNewCategory({...newCategory, name: e.target.value})}
                placeholder="اسم الفئة (انجليزي) *"
                className="w-full p-3 border rounded-lg"
              />
              <input
                type="text"
                value={newCategory.name_ar}
                onChange={(e) => setNewCategory({...newCategory, name_ar: e.target.value})}
                placeholder="اسم الفئة (عربي)"
                className="w-full p-3 border rounded-lg"
              />
              <input
                type="text"
                value={newCategory.icon}
                onChange={(e) => setNewCategory({...newCategory, icon: e.target.value})}
                placeholder="أيقونة (emoji أو رابط)"
                className="w-full p-3 border rounded-lg"
              />
            </div>

            <div className="flex gap-4 mt-6">
              <button onClick={createCategory} className="flex-1 bg-blue-600 text-white py-3 rounded-lg">إنشاء</button>
              <button onClick={() => setShowAddCategory(false)} className="flex-1 bg-gray-300 py-3 rounded-lg">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      {showCodesModal && selectedProduct && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 overflow-y-auto p-4">
          <div className="bg-white rounded-xl p-6 w-full max-w-3xl my-8">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="text-xl font-bold">إدارة الأكواد</h3>
                <p className="text-gray-500">{selectedProduct.name_ar || selectedProduct.name}</p>
              </div>
              <button onClick={() => setShowCodesModal(false)} className="text-gray-500 hover:text-gray-700">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="bg-green-50 p-4 rounded-lg text-center">
                <p className="text-2xl font-bold text-green-600">{codesCount.available}</p>
                <p className="text-sm text-gray-600">متوفر</p>
              </div>
              <div className="bg-red-50 p-4 rounded-lg text-center">
                <p className="text-2xl font-bold text-red-600">{codesCount.sold}</p>
                <p className="text-sm text-gray-600">مباع</p>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg text-center">
                <p className="text-2xl font-bold text-blue-600">{codesCount.total}</p>
                <p className="text-sm text-gray-600">الإجمالي</p>
              </div>
            </div>

            <div className="flex gap-2 mb-6">
              <button
                onClick={() => setCodesTab('view')}
                className={`px-4 py-2 rounded-lg ${codesTab === 'view' ? 'bg-blue-600 text-white' : 'bg-gray-100'}`}
              >
                عرض الأكواد
              </button>
              <button
                onClick={() => setCodesTab('single')}
                className={`px-4 py-2 rounded-lg ${codesTab === 'single' ? 'bg-blue-600 text-white' : 'bg-gray-100'}`}
              >
                إضافة كود فردي
              </button>
              <button
                onClick={() => setCodesTab('bulk')}
                className={`px-4 py-2 rounded-lg ${codesTab === 'bulk' ? 'bg-blue-600 text-white' : 'bg-gray-100'}`}
              >
                إضافة أكواد جماعية
              </button>
            </div>

            {codesTab === 'view' && (
              <div className="max-h-96 overflow-y-auto">
                {productCodes.length === 0 ? (
                  <p className="text-center text-gray-500 py-8">لا توجد أكواد. أضف أكوادًا للبدء.</p>
                ) : (
                  <table className="w-full text-sm">
                    <thead className="bg-gray-100 sticky top-0">
                      <tr>
                        <th className="p-2 text-right">الكود</th>
                        <th className="p-2 text-right">الرقم التسلسلي</th>
                        <th className="p-2 text-right">الحالة</th>
                        <th className="p-2 text-right">إجراءات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {productCodes.map(code => (
                        <tr key={code.id} className="border-b">
                          <td className="p-2 font-mono text-xs" dir="ltr">
                            {code.code.length > 30 ? code.code.substring(0, 30) + '...' : code.code}
                          </td>
                          <td className="p-2 text-gray-500">{code.serial_number || '-'}</td>
                          <td className="p-2">
                            <span className={`px-2 py-1 rounded text-xs ${code.is_sold ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                              {code.is_sold ? 'مباع' : 'متوفر'}
                            </span>
                          </td>
                          <td className="p-2">
                            <div className="flex gap-1">
                              <button
                                onClick={() => copyCode(code.code)}
                                className="p-1 text-gray-500 hover:text-blue-600"
                                title="نسخ"
                              >
                                <Copy className="w-4 h-4" />
                              </button>
                              {!code.is_sold && (
                                <button
                                  onClick={() => deleteCode(code.id)}
                                  className="p-1 text-gray-500 hover:text-red-600"
                                  title="حذف"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}

            {codesTab === 'single' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">الكود *</label>
                  <input
                    type="text"
                    value={newCode.code}
                    onChange={(e) => setNewCode({...newCode, code: e.target.value})}
                    className="w-full p-3 border rounded-lg font-mono"
                    placeholder="XXXX-XXXX-XXXX-XXXX"
                    dir="ltr"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">الرقم التسلسلي (اختياري)</label>
                  <input
                    type="text"
                    value={newCode.serial_number}
                    onChange={(e) => setNewCode({...newCode, serial_number: e.target.value})}
                    className="w-full p-3 border rounded-lg"
                    placeholder="SN123456"
                  />
                </div>
                <button
                  onClick={addSingleCode}
                  className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700"
                >
                  إضافة الكود
                </button>
              </div>
            )}

            {codesTab === 'bulk' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">الأكواد (كل كود في سطر)</label>
                  <p className="text-sm text-gray-500 mb-2">
                    للأكواد مع رقم تسلسلي، استخدم: الكود|الرقم_التسلسلي
                  </p>
                  <textarea
                    value={bulkCodesText}
                    onChange={(e) => setBulkCodesText(e.target.value)}
                    className="w-full p-3 border rounded-lg font-mono text-sm"
                    rows={8}
                    placeholder="XXXX-XXXX-XXXX-XXXX
YYYY-YYYY-YYYY-YYYY|SN123456
ZZZZ-ZZZZ-ZZZZ-ZZZZ"
                    dir="ltr"
                  />
                </div>
                <div className="text-sm text-gray-500">
                  عدد الأكواد: {bulkCodesText.split('\n').filter(l => l.trim()).length}
                </div>
                <button
                  onClick={addBulkCodes}
                  disabled={submitting}
                  className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 disabled:opacity-50"
                >
                  {submitting ? 'جاري الإضافة...' : 'إضافة الأكواد'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
